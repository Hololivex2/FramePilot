plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.framepilot.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.framepilot.app"; minSdk = 29; targetSdk = 35; versionCode = 1; versionName = "1.0.0" }
}
dependencies { implementation("androidx.core:core-ktx:1.13.1"); implementation("androidx.appcompat:appcompat:1.7.0") }
