package com.framepilot.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(pad, pad, pad, pad) }
        page.addView(TextView(this).apply { text = "FramePilot"; textSize = 32f })
        page.addView(TextView(this).apply { text = "Overlay helper\\nไม่ได้ปลดล็อก FPS หรือแก้ไขเกม"; textSize = 16f; setPadding(0, pad / 2, 0, pad) })
        status = TextView(this); page.addView(status)
        page.addView(Button(this).apply { text = "อนุญาต Overlay"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } })
        page.addView(Button(this).apply { text = "เปิด Overlay ทดสอบ"; setOnClickListener { if (Settings.canDrawOverlays(this@MainActivity)) startService(Intent(this@MainActivity, OverlayService::class.java)) } })
        page.addView(Button(this).apply { text = "หยุด Overlay"; setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) } })
        setContentView(page)
    }
    override fun onResume() { super.onResume(); status.text = if (Settings.canDrawOverlays(this)) "สถานะ: อนุญาต Overlay แล้ว" else "สถานะ: ยังไม่ได้อนุญาต Overlay" }
}
