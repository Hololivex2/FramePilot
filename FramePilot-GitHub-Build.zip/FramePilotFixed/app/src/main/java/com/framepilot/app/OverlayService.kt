package com.framepilot.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private var view: TextView? = null
    private lateinit var wm: WindowManager
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (view == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            view = TextView(this).apply { text = "FramePilot • Overlay test"; setTextColor(Color.WHITE); setBackgroundColor(0xCC1E3A8AL.toInt()); setPadding(24, 14, 24, 14) }
            wm.addView(view, WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 80 })
        }
        return START_NOT_STICKY
    }
    override fun onDestroy() { view?.let { wm.removeView(it) }; view = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
